# Examples

They are divided into 6 directories:

## Simple

Beginner stuff. Suitable for personal use, single-user situations only.

## Chat

Many-user, chat-only interactions. Basic use of `DelegatorBot`.

## Inline

Handles inline query using `Answerer`.

## Callback

Various styles of handling callback query.

## Webhook

How to integrate telepot with webhook.

## Deep Linking

Demonstration of deep linking.

## Payment

How to handle payments.

## Event

Use the built-in scheduler to schedule custom events
