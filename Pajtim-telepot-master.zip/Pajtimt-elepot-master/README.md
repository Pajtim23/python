# telepot - Python framework for Telegram Bot API

**[Bot API 3.6](https://core.telegram.org/bots/api)**-compliant!

### [Introduction »](http://telepot.readthedocs.io/en/latest/)
### [Reference »](http://telepot.readthedocs.io/en/latest/reference.html)
### [Examples »](https://github.com/nickoala/telepot/tree/master/examples)
### [Changelog »](https://github.com/nickoala/telepot/blob/master/CHANGELOG.md)
